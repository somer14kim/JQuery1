function alertHover(){
  document.getElementById("area").style.backgroundColor = "green";
  alert("Close me to turn the box green.");
}

function reset(){
   document.getElementById("area").style.backgroundColor = "#953674"; 
}